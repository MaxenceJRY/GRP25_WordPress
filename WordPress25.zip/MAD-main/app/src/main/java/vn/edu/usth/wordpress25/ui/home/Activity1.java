package vn.edu.usth.wordpress25.ui.home;

import androidx.appcompat.app.AppCompatActivity;

public class Activity1 extends AppCompatActivity {
}
