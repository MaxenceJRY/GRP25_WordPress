package vn.edu.usth.wordpress25.ui.notifications;

import androidx.fragment.app.Fragment;

public class emptyfragment extends Fragment {
}
